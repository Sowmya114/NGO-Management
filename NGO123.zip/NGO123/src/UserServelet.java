

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.UserDaoImp1.UserDaoImp1;
import com.cognizant.userBean.*;

/**
 * Servlet implementation class User
 */
@WebServlet("/UserServelet")
public class UserServelet extends HttpServlet {
	 int k;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String fname=request.getParameter("First_Name");
		String lname=request.getParameter("Last_Name");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		String email=request.getParameter("email");
		System.out.print(email);
		String password=request.getParameter("psw");
		
		User u=new User();
		u.setFname(fname);
	    u.setLname(lname);
	    u.setAge(age);
	    u.setGender(gender);
	    u.setEmail(email);
	    u.setPass(password);
		try {
			k = UserDaoImp1.saveUser(u);
		} catch (Exception e) {
		
			ServletContext sc=getServletContext();
			sc.setAttribute("error1", e);
			response.sendRedirect("");
					
		}
	    if(k>0)
	    {
	    out.print("<script>alert('saved')</script>");
	    response.sendRedirect("home.html");
	    }
	}

}
