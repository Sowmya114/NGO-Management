package com.cognizant.AdminDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {
	static Connection con;
	public static Connection  getConnect() 
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root","root");
			
			
		}
		catch(Exception e)
		{
			System.out.println("Error in connection"+e);
		}
		return con;
		}
	
	public static int checkLogin(String mail, String verify) throws SQLException
	{
		int k=0;
		Connection con=getConnect();
		
			String user="Sowmya.M";
			String pass="Cognizant123";
			
			if(user.equals(mail)&& pass.equals(verify))
			{   
				k=1;
		     	System.out.println(user+" " +pass);
		     }
			else
			{
				k=0;	
			}
				
		
		return k;
	}
}
