package com.cognizant;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.UserDaoImp1.UserDaoImp1;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       int c;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		String username=request.getParameter("id");
		String password=request.getParameter("password");
		
		PrintWriter out=response.getWriter();
		try {
			 c=UserDaoImp1.checkLogin(username,password);
			// System.out.println(c);
			
			 
			 
			 
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		if(c==1)
		{
			 HttpSession session=request.getSession();
			 session.setAttribute("key1", username);
			 out.print("<script>alert('Welcome to Smile Foundation!')</script>");
			 RequestDispatcher rd=request.getRequestDispatcher("WelcomeUser.jsp");
			 rd.include(request, response);
			 
			 
		
		}
		
		else
			out.print("<script>alert('Error while loging or Entry might be Deleted')</script>");
	}

}
