package com.cognizant.UserDaoImp1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cognizant.userBean.*;

public class NgoDao {
	static Connection con;
	public static Connection  getConnect() 
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root","root");
			
			
		}
		catch(Exception e)
		{
			System.out.println("Error in connection"+e);
		}
		return con;
		}
	public static int saveNGO(Ngo n)throws Exception
	{
	Connection con=getConnect();
	PreparedStatement ps=con.prepareStatement("insert into Ngo values(?,?,?,?,?,?)");
	ps.setString(1,n.getId());
	ps.setString(2,n.getName());
	ps.setString(3,n.getDate());
	ps.setLong(4,n.getContact());
	ps.setString(5,n.getEmail());
	ps.setString(6,n.getPassword());
	int k=ps.executeUpdate();
	System.out.println(k);
	return k;
	}




	public static int checkLogin(String mail, String verify) throws SQLException
	{
		int k=0;
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select * from Ngo");
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			String user=rs.getString("email");
			String pass=rs.getString("password");
			System.out.println(user+pass);
			if(user.equals(mail)&& pass.equals(verify))
			{   k=1;
			System.out.println(user+pass);
		     	break;
		     	}
			else
			{
				k=0;	
			}
				
		}
		return k;
	}
}
